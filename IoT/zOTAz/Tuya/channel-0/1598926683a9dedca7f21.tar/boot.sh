echo "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

export LD_LIBRARY_PATH=/mnt/mtd/lib:$LD_LIBRARY_PATH

COLOR_NORMAL="\e[0;39m"
COLOR_RED="\e[1;31m"
COLOR_GREEN="\e[1;32m"
COLOR_YELLOW="\e[1;33m"
COLOR_BLUE="\e[1;34m"


############################get device config start####################################
sensorName=""
config_file_name=""
devtype=""
isNeedPIR=0
if [ -r /mnt/mtd/product_type/TUYA_COMM_DEVICE ];then
#### new tuya packet	
	echo "tuya comm packet"
	if [ -r /mnt/mtd/SystemConfig.ini ];then
		config_file_name=/mnt/mtd/SystemConfig.ini
		sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
		devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
	fi
	
	if [ -r /mnt/mtd/SystemConfig.ini_backup ];then
		if [ ! $devtype ] || [ ! $sensorName ];then
			config_file_name=/mnt/mtd/SystemConfig.ini_backup 
			sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
			devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
		fi
	fi
	
	if [ -r /mnt/mtd/TuyaDevConfig.ini ];then
		if [ ! $devtype ] || [ ! $sensorName ];then
			config_file_name=/mnt/mtd/TuyaDevConfig.ini 
			sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
			devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
		fi
	fi
	
	if [ -r /mnt/mtd/TuyaSensorConfig.ini ];then
		if [ ! $devtype ] || [ ! $sensorName ];then
			config_file_name=/mnt/mtd/TuyaSensorConfig.ini 
			sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
			devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
		fi
	fi
	
	sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`   
	echo -e ${COLOR_GREEN}"get sensor name from $config_file_name,sensor is "$sensorName${COLOR_NORMAL} 
	
	
	devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
	if [ $devtype ];then
		echo -e ${COLOR_GREEN}"get device type from $config_file_name,type is "$devtype${COLOR_NORMAL}
	else
		echo -e ${COLOR_RED}"get device type from $config_file_name,but devtype is null,need to set by factorytool"${COLOR_NORMAL}
	fi
else
#### old tuya packet
	devtype=`ls /mnt/mtd/product_type/|sed s/[[:space:]]//g`
	if [ $devtype == "TUYA_966G2" ] \
		||[ $devtype == "PIC3005WN" ] \
		||[ $devtype == "TUYA_966G2_COMMON" ] \
		||[ $devtype == "TUYA_977GC" ] \
		||[ $devtype == "TUYA_97AE2" ] \
		||[ $devtype == "TUYA_97C" ] \
		||[ $devtype == "TUYA_968" ];then 
		sensorName=gc2033
	elif [ $devtype == "TUYA_975" ] \
			||[ $devtype == "TUYA_952E2" ] \
			||[ $devtype == "PIC3003WP" ];then	
		sensorName=sc2235
	fi
	
	echo -e ${COLOR_GREEN}"Compatible with old tuya packet,old dev type is"$devtype",sensor is "$sensorName${COLOR_NORMAL}
	
fi
############################get device config end####################################


####################adapter led start #################################
##################TUYA red on######################
if [ "TUYA_977GC" == $devtype ] || [ "TUYA_977GC_CFG" == $devtype ] \
   || [ "TUYA_975" == $devtype ] || [ "TUYA_975_CFG" == $devtype ] \
   || [ "TUYA_968" == $devtype ] || [ "TUYA_968_CFG" == $devtype ];then
	echo -e ${COLOR_GREEN}$devtype" led red is gpio 7-4,blue is gpio 7-5"${COLOR_NORMAL}
	
	himm 0x201B0400 0x30
	
	#red gpio 7-4 low
	himm 0x200F00F0 0x01
	#himm 0x201B0400 0x10
	himm 0x201B0040 0x00 # high:0x10 low:0x00

	#blue gpio 7-5 high
	himm 0x200F00F4 0x01
	#himm 0x201B0400 0x20
	himm 0x201B0080 0x20 # high:0x20 low:0x00

else
	echo -e ${COLOR_GREEN}$devtype" lend red is gpio 7-5,blue is gpio 7-4"${COLOR_NORMAL}
	
	himm 0x201B0400 0x30
	
	#blue gpio 7-4 high
	himm 0x200F00F0 0x01
	#himm 0x201B0400 0x10
	himm 0x201B0040 0x10 # high:0x10 low:0x00

	#red gpio 7-5 low
	himm 0x200F00F4 0x01
	#himm 0x201B0400 0x20
	himm 0x201B0080 0x00 ## high:0x20 low:0x00
fi
####################adapter led end #################################

############################wifi start####################################
echo "=========wifi power on========="
himm 0x200F0078 0x00
himm 0x20140400 0x04
himm 0x20140010 0x00
sleep 2
himm 0x20140010 0x04
sleep 2

cd /ko
insmod rtl8192eu.ko
############################wifi end####################################


############################media start####################################
if [ "" != "$sensorName" ];then
	echo -e ${COLOR_GREEN}"to load3518e drivers,sensor is "$sensorName${COLOR_NORMAL}
	ln -sf /mnt/mtd/lib/libsns_$sensorName"".so /mnt/mtd/lib/libsns_sensor.so
	/mnt/mtd/load3518e -a -sensor $sensorName
else
	echo -e  "\e[1;33m""boot.sh:""\e[0;31m""Serious error!!!!I don't known which sensor to config,some errors may occur!!!""\e[0m"
	ln -sf /mnt/mtd/lib/libsns_gc2033.so /mnt/mtd/lib/libsns_sensor.so
	/mnt/mtd/load3518e -a
fi
############################media end####################################


############################pir driver start####################################
if [ $devtype ];then
	if [ "TUYA_97C_CFG" == $devtype ] \
		||[ "TUYA_97C" == $devtype ] \
		||[ "TUYA_97AE2_CFG" == $devtype ] \
		||[ "TUYA_97AE2" == $devtype ] \
		||[ "TUYA_975_CFG" == $devtype ] \
		||[ "TUYA_975" == $devtype ];then 
		echo -e ${COLOR_GREEN}"if device type is 975||97A||97C,need to load PIR.ko"${COLOR_NORMAL}
		insmod /mnt/mtd/PIR.ko
	fi
else
	echo -e ${COLOR_RED}"device type is null,not to load PIR.ko"${COLOR_NORMAL}
fi
############################pir driver end####################################


############################application start####################################
cd /mnt/mtd
./socket_system_server &

echo "If you want to run app by yourself, please input q "
read -t 2 -p "=======================Press q -> Entry ?" exit_cmd
if [ "$exit_cmd" == "q" ] ; then
	exit
fi

./daemon &
./aoni_ipc &
############################application end####################################

