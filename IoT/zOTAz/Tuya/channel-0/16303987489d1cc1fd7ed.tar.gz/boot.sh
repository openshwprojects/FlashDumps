export LD_LIBRARY_PATH=/mnt/mtd/lib:$LD_LIBRARY_PATH
export PATH=$PATH:/mnt/mtd/

COLOR_NORMAL="\e[0;39m"
COLOR_RED="\e[1;31m"
COLOR_GREEN="\e[1;32m"
COLOR_YELLOW="\e[1;33m"
COLOR_BLUE="\e[1;34m"

function gpio_set_value()
{
    echo "set gpio$1 value to $2 "
    echo $1 > /sys/class/gpio/export
    echo out > /sys/class/gpio/gpio$1/direction
    echo $2 > /sys/class/gpio/gpio$1/value
}

############################get device config start####################################
sensorName=""
config_file_name=""
original_devtype=""
devtype_pref=""
devtype=""

isNeedPIR=0

if [ ! -d "/mnt/mtd/product_type" ];then
    mkdir -p /mnt/mtd/product_type
    touch /mnt/mtd/product_type/TUYA_RT3903_COMM_DEVICE
fi

if [ -r /mnt/mtd/product_type/TUYA_RT3903_COMM_DEVICE ];then
#### new tuya packet
        echo "tuya comm packet"
        if [ -r /mnt/mtd/SystemConfig.ini ];then
                config_file_name=/mnt/mtd/SystemConfig.ini
                sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
                original_devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
        fi

        if [ -r /mnt/mtd/SystemConfig.ini_backup ];then
                if [ ! $original_devtype ] || [ ! $sensorName ];then
                        config_file_name=/mnt/mtd/SystemConfig.ini_backup 
                        sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
                        original_devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
                fi
        fi

        if [ -r /mnt/mtd/TuyaDevConfig.ini ];then
                if [ ! $original_devtype ] || [ ! $sensorName ];then
                        config_file_name=/mnt/mtd/TuyaDevConfig.ini 
                        sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
                        original_devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
                fi
        fi

        if [ -r /mnt/mtd/TuyaSensorConfig.ini ];then
                if [ ! $original_devtype ] || [ ! $sensorName ];then
                        config_file_name=/mnt/mtd/TuyaSensorConfig.ini 
                        sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`    
                        original_devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
                fi
        fi

	if [ $config_file_name ];then
        	#sensorName=`grep "Product_SENSOR_NAME" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g| tr 'A-Z' 'a-z'`   
       		echo -e ${COLOR_GREEN}"get sensor name from $config_file_name,sensor is "$sensorName${COLOR_NORMAL} 
        	#original_devtype=`grep "Product_DEVICE_TYPE" $config_file_name |cut -d"=" -f 2|sed s/[[:space:]]//g`
			
			devtype_pref=${original_devtype%%_*}_   #取第一个_及之前的子串
			if [ $devtype_pref == "TUYA_" ];then
				devtype=${original_devtype#*_}      #取第一个_之后的子串
			else
				devtype=$original_devtype
			fi
			
        	if [ $devtype ];then
                	echo -e ${COLOR_GREEN}"get device type from $config_file_name,type is "$devtype${COLOR_NORMAL}
        	else
                	echo -e ${COLOR_RED}"get device type from $config_file_name,but devtype is null,need to set by factorytool"${COLOR_NORMAL}
        	fi
	else
       		echo -e  "\e[1;33m""boot.sh:""\e[0;31m""Serious error!!!!have not any cfg file,need TuyaSensorConfig.ini at lease !!!""\e[0m"
	fi
else
	####for testing
        original_devtype=`ls /mnt/mtd/product_type/|sed s/[[:space:]]//g`
			
	devtype_pref=${original_devtype%%_*}_   #取第一个_及之前的子串
	if [ $devtype_pref == "TUYA_" ];then
	    devtype=${original_devtype#*_}      #取第一个_之后的子串
	else
	    devtype=$original_devtype
	fi
		
        if [ $devtype == "RT3906_97A" ];then
                sensorName=gc2053
        elif [ $devtype == "RT3906_980" ] || 
	     [ $devtype == "RT3906_977" ] || 
	     [ $devtype == "RT3906_97U" ] ||
	     [ $devtype == "RT3906_966" ] ||
	     [ $devtype == "RT3906_95A" ] ||
		 [ $devtype == "RT3906_97P" ] ||
	     [ $devtype == "RT3906_952" ] ;then
                sensorName=jxf23
        elif [ $devtype == "RT3906_96F" ] || 
	     [ $devtype == "RT3906_96K" ] ||
             [ $devtype == "RT3906_958" ]  ;then 
                sensorName=jxf37
	else
                sensorName=jxf23
        fi

        echo -e ${COLOR_GREEN}"Compatible with old tuya packet,old dev type is"$devtype",sensor is "$sensorName${COLOR_NORMAL}
fi
############################get device config end####################################


############################wifi start####################################
echo "=========wifi power on========="
############################wifi end####################################

############################speaker start##########################################
echo "=============speaker disable================="
if [ "RT3906_97A" == $devtype ] || [ "RTS3906N_97A_R72_CFG" == $devtype ] || [ "RT3906_97P_R7C_CFG" == $devtype ] ;then
	echo -e ${COLOR_GREEN}$devtype" speaker power is gpio 18,low valid"${COLOR_NORMAL}
	gpio_set_value 18 1
elif [ "RT3906_980" == $devtype ] || [ "RT3906_980_R7C_CFG" == $devtype ] ||
     [ "RT3906_977" == $devtype ] || [ "RT3906_977_R7C_CFG" == $devtype ] ||
     [ "RT3906_97U" == $devtype ] || [ "RT3906_97U_R72_CFG" == $devtype ] ||
     [ "RT3906_966" == $devtype ] || [ "RT3906_966_R02_CFG" == $devtype ] ||
     [ "RT3906_95A" == $devtype ] || [ "RT3906_95A_R7C_CFG" == $devtype ] ||
     [ "RT3906_958" == $devtype ] || [ "RT3906_958_R7C_CFG" == $devtype ] ||
     [ "RT3906_952" == $devtype ] || [ "RT3906_952_R42_CFG" == $devtype ] ;then
	echo -e ${COLOR_GREEN}$devtype" speaker power is gpio 18,high valid"${COLOR_NORMAL}
	gpio_set_value 18 0
else
	echo -e ${COLOR_GREEN}$devtype"speaker unsupport devtype"${COLOR_NORMAL}
fi
############################speaker end###########################################


####################adapter led start #################################
##################TUYA red on######################
if [ "RT3906_97A" == $devtype ] || [ "RTS3906N_97A_R72_CFG" == $devtype ] || [ "RT3906_97P_R7C_CFG" == $devtype ] ;then
	echo -e ${COLOR_GREEN}$devtype" led red is gpio 6,blue is gpio 22"${COLOR_NORMAL}
	gpio_set_value 6 0
	gpio_set_value 22 1 
elif [ "RTS3906_980" == $devtype ] || [ "RT3906_980_R7C_CFG" == $devtype ] || 
     [ "RT3906_977" == $devtype ] || [ "RT3906_977_R7C_CFG" == $devtype ] ||
     [ "RT3906_97U" == $devtype ] || [ "RT3906_97U_R72_CFG" == $devtype ] ||
     [ "RT3906_958" == $devtype ] || [ "RT3906_958_R7C_CFG" == $devtype ] ;then
	echo -e ${COLOR_GREEN}$devtype" red is gpio 16,blue is gpio 22"${COLOR_NORMAL}
	gpio_set_value 16 0
	gpio_set_value 22 1 
elif [ "RT3906_95A" == $devtype ] || [ "RT3906_95A_R7C_CFG" == $devtype ] ||
     [ "RT3906_952" == $devtype ] || [ "RT3906_952_R42_CFG" == $devtype ] ;then
	echo -e ${COLOR_GREEN}$devtype" red is gpio 8,blue is gpio 22"${COLOR_NORMAL}
	gpio_set_value 8 0
	gpio_set_value 22 1 
elif [ "RT3906_966" == $devtype ] || [ "RT3906_966_R02_CFG" == $devtype ] ;then
	echo -e ${COLOR_GREEN}$devtype" red is gpio 22,blue is gpio 8"${COLOR_NORMAL}
	gpio_set_value 22 0
	gpio_set_value 8 1 
else
	echo -e ${COLOR_GREEN}$devtype"led unsupport devtype"${COLOR_NORMAL}
fi

####################adapter led end #################################
echo "<<<<<<<<<<<<<<<<<<<< devtype is $devtype >>>>>>>>>>>>>>>>>>>>>>"
echo "<<<<<<<<<<<<<<<<<<<< sensorName is $sensorName >>>>>>>>>>>>>>>>>>>>>>"
############################media start####################################
#if [ "RT3906_97P_R7C_CFG" == $devtype ];then 
#		ln -sf /mnt/mtd/lib/firmware/sensor_fw_jxf23-97P.bin /mnt/mtd/lib/firmware/isp.fw 
#else
	if [ "" != "$sensorName" ];then
			echo -e ${COLOR_GREEN}"to load3518e drivers,sensor is "$sensorName${COLOR_NORMAL}
			ln -sf /mnt/mtd/lib/firmware/sensor_fw_$sensorName"".bin /mnt/mtd/lib/firmware/isp.fw 
	else
			echo -e  "\e[1;33m""boot.sh:""\e[0;31m""Serious error!!!!I don't known which sensor to config,some errors may occur!!!""\e[0m"
			ln -sf /mnt/mtd/lib/firmware/sensor_fw_jxf23.bin /mnt/mtd/lib/firmware/isp.fw 
	fi		
#fi
echo /mnt/mtd/lib/firmware/isp.fw > /sys/class/rts_camera/rtsmcu/device/loadfw
############################media end####################################


############################pir driver start####################################
if [ $devtype ];then
        if [ "RT3906_97A" == $devtype ] || [ "RT3906_97A_R72_CFG" == $devtype ] || [ "RT3906_97P_R7C_CFG" == $devtype ];then 
                echo -e ${COLOR_GREEN}"if device type is 975||97A||97C||97P,need to load PIR.ko"${COLOR_NORMAL}
                insmod /mnt/mtd/lib/modules/PIR.ko
        fi
else
        echo -e ${COLOR_RED}"device type is null,not to load PIR.ko"${COLOR_NORMAL}
fi
############################pir driver end####################################

############################system init start####################################
echo 3 > /proc/sys/vm/drop_caches > /dev/null
/etc/init.d/S50telnet stop
echo 2048 > /proc/sys/vm/min_free_kbytes
#telnetd&
############################system init end####################################

############################application start####################################
cd /mnt/mtd
./socket_system_server &

echo "sleep 3 seconds wait sd card!!!"
sleep 3

echo "If you want to run app by yourself, please input q "
read -t 2 -p "=======================Press q -> Entry ?" exit_cmd
if [ "$exit_cmd" == "q" ] ; then
        exit
fi

./daemon &
#./aoni_ipc &
############################application end####################################
