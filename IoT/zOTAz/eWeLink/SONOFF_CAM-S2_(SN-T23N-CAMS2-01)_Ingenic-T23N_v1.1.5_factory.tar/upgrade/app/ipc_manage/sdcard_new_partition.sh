#!/bin/sh

echo "d
8
d
7
d
6
d
5
d
4
d
3
d
2
d
1
n
p
1


w
" | fdisk /dev/mmcblk0
